﻿using System;
using System.Data.Entity;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace PP02._02
{
    public partial class productSaleAddPage : Page
    {
        productsale curSale = new productsale();
        MainWindow main;
        private bool isEdit = false;
        int uID;

        public productSaleAddPage(MainWindow main, int ID)
        {
            InitializeComponent();
            comboLoad();
            Load(ID);
            isEdit = true;
            this.main = main;
            uID = ID;
        }

        public productSaleAddPage(MainWindow main)
        {
            InitializeComponent();
            this.main = main;
            comboLoad();
            datePicker.SelectedDate = DateTime.Now;
        }

        private void comboLoad()
        {
            try
            {
                OrgCombo.ItemsSource = Context.GetContext().agents
                    .OrderBy(c => c.Наименование_агента)
                    .ToList();
                OrgCombo.DisplayMemberPath = "Наименование_агента";
                OrgCombo.SelectedValuePath = "АйдиАгента";

                ProdCombo.ItemsSource = Context.GetContext().products
                    .OrderBy(c => c.Наименование_продукции)
                    .ToList();
                ProdCombo.DisplayMemberPath = "Наименование_продукции";
                ProdCombo.SelectedValuePath = "АйдиПродукта";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки списков: {ex.Message}");
            }
        }

        private void Load(int ID)
        {
            try
            {
                curSale = Context.GetContext().productsales
                    .FirstOrDefault(z => z.АйдиПродажи == ID);

                if (curSale != null)
                {
                    this.DataContext = curSale;

                    OrgCombo.SelectedValue = curSale.АйдиАгента;
                    ProdCombo.SelectedValue = curSale.АйдиПродукта;
                }
                else
                {
                    MessageBox.Show("Закупка не найдена");
                    main.mainFrame.Navigate(new productSalePage(main));
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки: {ex.Message}");
            }
        }

        private void cancelBtn_Click(object sender, RoutedEventArgs e)
        {
            main.mainFrame.Navigate(new productSalePage(main));
        }

        private void saveBtn_Click(object sender, RoutedEventArgs e)
        {
            if (OrgCombo.SelectedValue == null)
            {
                MessageBox.Show("Выберите агента");
                return;
            }

            if (ProdCombo.SelectedValue == null)
            {
                MessageBox.Show("Выберите продукт");
                return;
            }

            if (datePicker.SelectedDate == null)
            {
                MessageBox.Show("Выберите дату реализации");
                return;
            }

            if (string.IsNullOrEmpty(Count.Text) || !int.TryParse(Count.Text, out int countValue) || countValue <= 0)
            {
                MessageBox.Show("Введите корректное количество продукции (больше 0)");
                return;
            }

            try
            {
                curSale.АйдиАгента = (int)OrgCombo.SelectedValue;
                curSale.АйдиПродукта = (int)ProdCombo.SelectedValue;
                curSale.Дата_реализации = datePicker.SelectedDate.Value;
                curSale.Количество_продукции = countValue;

                if (!isEdit)
                {
                    Context.GetContext().Database.ExecuteSqlCommand(
                        "EXEC dbo.InsertProductSale @p0, @p1, @p2, @p3",
                        curSale.АйдиПродукта,
                        curSale.АйдиАгента,
                        curSale.Дата_реализации,
                        curSale.Количество_продукции
                    );
                }
                else
                {
                    Context.GetContext().Database.ExecuteSqlCommand(
                        "EXEC dbo.UpdateProductSale @p0, @p1, @p2, @p3, @p4",
                        curSale.АйдиПродажи,
                        curSale.АйдиПродукта,
                        curSale.АйдиАгента,
                        curSale.Дата_реализации,
                        curSale.Количество_продукции
                    );
                }

                RefreshContext();

                MessageBox.Show(isEdit ? "Закупка обновлена" : "Закупка добавлена");
                main.mainFrame.Navigate(new productSalePage(main));
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка сохранения: {ex.Message}");
            }
        }

        private void RefreshContext()
        {
            try
            {
                var context = Context.GetContext();

                context.ChangeTracker.Entries()
                    .Where(e => e.Entity != null)
                    .ToList()
                    .ForEach(e => e.State = EntityState.Detached);

                int agentId = (int)OrgCombo.SelectedValue;
                var agent = context.agents
                    .FirstOrDefault(a => a.АйдиАгента == agentId);

                if (agent != null)
                {
                    agent.Скидка = context.Database.SqlQuery<int?>(
                        "SELECT Скидка FROM agents WHERE АйдиАгента = @p0",
                        agentId
                    ).FirstOrDefault();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка обновления контекста: {ex.Message}");
            }
        }
    }
}