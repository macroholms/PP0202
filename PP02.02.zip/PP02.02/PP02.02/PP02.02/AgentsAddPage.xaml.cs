﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;
using Microsoft.Win32;

namespace PP02._02
{
    public partial class AgentsAddPage : Page
    {
        agent curAgent = new agent();
        MainWindow main;
        private bool isEdit = false;
        int uID;
        private byte[] selectedLogo = null;

        public AgentsAddPage(MainWindow main, int ID)
        {
            InitializeComponent();
            comboLoad();
            Load(ID);
            isEdit = true;
            this.main = main;
            uID = ID;
        }

        public AgentsAddPage(MainWindow main)
        {
            InitializeComponent();
            this.main = main;
            comboLoad();

            SetDefaultLogo();
        }

        private void comboLoad()
        {
            OrgTypeCombo.ItemsSource = Context.GetContext().agents_type.OrderBy(c => c.Тип_агента).ToList();
            OrgTypeCombo.DisplayMemberPath = "Тип_агента";
            OrgTypeCombo.SelectedValuePath = "АйдиТипа";
        }

        private void Load(int ID)
        {
            try
            {
                curAgent = Context.GetContext().agents
                    .FirstOrDefault(z => z.АйдиАгента == ID);

                if (curAgent != null)
                {
                    OrgName.Text = curAgent.Наименование_агента;
                    OrgMail.Text = curAgent.Электронная_почта_агента;
                    OrgPhone.Text = curAgent.Телефон_агента;
                    OrgAddres.Text = curAgent.Юридический_адрес;
                    OrgDirectorFIO.Text = curAgent.Директор;
                    OrgINN.Text = curAgent.ИНН;
                    OrgKPP.Text = curAgent.КПП;

                    OrgTypeCombo.SelectedValue = curAgent.ТипАгента;

                    if (curAgent.Логотип_агента != null && curAgent.Логотип_агента.Length > 0)
                    {
                        ShowLogo(curAgent.Логотип_агента);
                        selectedLogo = curAgent.Логотип_агента;
                    }
                    else
                    {
                        SetDefaultLogo();
                    }
                }
                else
                {
                    MessageBox.Show("Агент не найден");
                    main.mainFrame.Navigate(new AgentsPage(main));
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки: {ex.Message}");
            }
        }

        private void ShowLogo(byte[] logoBytes)
        {
            try
            {
                using (var stream = new MemoryStream(logoBytes))
                {
                    var bitmap = new BitmapImage();
                    bitmap.BeginInit();
                    bitmap.CacheOption = BitmapCacheOption.OnLoad;
                    bitmap.StreamSource = stream;
                    bitmap.EndInit();
                    LogoPreview.Source = bitmap;
                }
            }
            catch
            {
                SetDefaultLogo();
            }
        }

        private void SetDefaultLogo()
        {
            try
            {
                LogoPreview.Source = new BitmapImage(new Uri("/agents/picture.png", UriKind.Relative));
            }
            catch
            {
                LogoPreview.Source = null;
            }
        }

        private void selectLogoBtn_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image files (*.jpg, *.jpeg, *.png, *.bmp)|*.jpg;*.jpeg;*.png;*.bmp";
            openFileDialog.Title = "Выберите логотип";

            if (openFileDialog.ShowDialog() == true)
            {
                try
                {
                    selectedLogo = File.ReadAllBytes(openFileDialog.FileName);

                    ShowLogo(selectedLogo);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка загрузки файла: {ex.Message}");
                    selectedLogo = null;
                    SetDefaultLogo();
                }
            }
        }

        private void cancelBtn_Click(object sender, RoutedEventArgs e)
        {
            main.mainFrame.Navigate(new AgentsPage(main));
        }

        private void saveBtn_Click(object sender, RoutedEventArgs e)
        {
            if (OrgTypeCombo.SelectedValue == null)
            {
                MessageBox.Show("Выберите тип");
                return;
            }

            if (string.IsNullOrEmpty(OrgName.Text) ||
                string.IsNullOrEmpty(OrgPhone.Text) ||
                string.IsNullOrEmpty(OrgAddres.Text) ||
                string.IsNullOrEmpty(OrgMail.Text) ||
                string.IsNullOrEmpty(OrgKPP.Text) ||
                string.IsNullOrEmpty(OrgINN.Text) ||
                string.IsNullOrEmpty(OrgDirectorFIO.Text))
            {
                MessageBox.Show("Не все поля заполнены");
                return;
            }

            try
            {
                curAgent.Наименование_агента = OrgName.Text;
                curAgent.Электронная_почта_агента = OrgMail.Text;
                curAgent.ТипАгента = (int)OrgTypeCombo.SelectedValue;
                curAgent.Телефон_агента = OrgPhone.Text;
                curAgent.Юридический_адрес = OrgAddres.Text;
                curAgent.Директор = OrgDirectorFIO.Text;
                curAgent.ИНН = OrgINN.Text;
                curAgent.КПП = OrgKPP.Text;

                if (selectedLogo != null)
                {
                    curAgent.Логотип_агента = selectedLogo;
                }
                else if (!isEdit && curAgent.Логотип_агента == null)
                {
                    curAgent.Логотип_агента = null;
                }

                if (!isEdit)
                {
                    int priority = Context.GetContext().Database.SqlQuery<int>("SELECT MAX(Приоритет) FROM agents").First() + 1;
                    curAgent.Приоритет = priority;
                }

                if (!isEdit)
                {
                    Context.GetContext().Database.ExecuteSqlCommand(
                        "EXEC dbo.InsertAgent @p0, @p1, @p2, @p3, @p4, @p5, @p6, @p7, @p8, @p9",
                        curAgent.ТипАгента,
                        curAgent.Наименование_агента,
                        curAgent.Электронная_почта_агента,
                        curAgent.Телефон_агента,
                        curAgent.Логотип_агента ?? (object)DBNull.Value,
                        curAgent.Юридический_адрес,
                        curAgent.Директор,
                        curAgent.ИНН,
                        curAgent.КПП,
                        curAgent.Скидка ?? (object)DBNull.Value
                    );
                }
                else
                {
                    Context.GetContext().Database.ExecuteSqlCommand(
                        "EXEC dbo.UpdateAgent @p0, @p1, @p2, @p3, @p4, @p5, @p6, @p7, @p8, @p9, @p10, @p11",
                        curAgent.АйдиАгента,
                        curAgent.ТипАгента,
                        curAgent.Наименование_агента,
                        curAgent.Электронная_почта_агента,
                        curAgent.Телефон_агента,
                        curAgent.Логотип_агента ?? (object)DBNull.Value,
                        curAgent.Юридический_адрес,
                        curAgent.Приоритет,
                        curAgent.Директор,
                        curAgent.ИНН,
                        curAgent.КПП,
                        curAgent.Скидка ?? (object)DBNull.Value
                    );
                }

                MessageBox.Show(isEdit ? "Агент обновлен" : "Агент добавлен");
                main.mainFrame.Navigate(new AgentsPage(main));
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка сохранения: {ex.Message}");
            }
        }

        private void removeLogoBtn_Click(object sender, RoutedEventArgs e)
        {
            selectedLogo = null;
            SetDefaultLogo();
        }
    }
}