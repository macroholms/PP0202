﻿using System;
using System.ComponentModel;
using System.IO;
using System.Windows.Media.Imaging;

namespace PP02._02
{
    public class AgentViewModel : INotifyPropertyChanged
    {
        private AgentsView _agent;

        public AgentViewModel(AgentsView agent)
        {
            _agent = agent;
        }

        public int АйдиАгента => _agent.АйдиАгента;
        public string Наименование_типа_организации => _agent.Наименование_типа_организации;
        public string Наименование_организации => _agent.Наименование_организации;
        public int? Количество_продаж_за_год => _agent.Количество_продаж_за_год;
        public string Номер_телефона => _agent.Номер_телефона;
        public int Приоритетность => _agent.Приоритетность;
        public int? Скидка => _agent.Скидка;
        public byte[] Ссылка_на_логотип => _agent.Ссылка_на_логотип;

        public BitmapImage LogoImage
        {
            get
            {
                if (_agent.Ссылка_на_логотип == null || _agent.Ссылка_на_логотип.Length == 0)
                {
                    return LoadDefaultImage();
                }

                try
                {
                    using (var stream = new MemoryStream(_agent.Ссылка_на_логотип))
                    {
                        var bitmap = new BitmapImage();
                        bitmap.BeginInit();
                        bitmap.CacheOption = BitmapCacheOption.OnLoad;
                        bitmap.StreamSource = stream;
                        bitmap.EndInit();
                        bitmap.Freeze();
                        return bitmap;
                    }
                }
                catch
                {
                    return LoadDefaultImage();
                }
            }
        }

        private BitmapImage LoadDefaultImage()
        {
            try
            {
                var bitmap = new BitmapImage();
                bitmap.BeginInit();
                bitmap.UriSource = new Uri("pack://application:,,,/agents/picture.png");
                bitmap.CacheOption = BitmapCacheOption.OnLoad;
                bitmap.EndInit();
                bitmap.Freeze();
                return bitmap;
            }
            catch
            {
                return null;
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}