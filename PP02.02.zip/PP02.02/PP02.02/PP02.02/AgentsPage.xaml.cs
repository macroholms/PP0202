﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PP02._02
{
    public partial class AgentsPage : Page
    {
        private MainWindow main;
        private List<AgentsView> allAgents;
        private ObservableCollection<AgentViewModel> displayedAgents;
        private int currentPage = 1;
        private const int pageSize = 10;
        private string[] fields = { "Тип организации", "Наименование", "Количество продаж", "Номер телефона", "Приоритетность", "Скидка" };

        private string currentSortField;
        private bool isAscending = true;
        private string currentFilterType;
        private string currentSearchText = "";

        public string CurrentPageInfo;
        public int TotalPages;

        public AgentsPage(MainWindow main)
        {
            InitializeComponent();
            this.main = main;
            displayedAgents = new ObservableCollection<AgentViewModel>();
            LoadData();
            ComboLoad();
            MainListView.ItemsSource = displayedAgents;
            DataContext = this;
        }

        private void ComboLoad()
        {
            var db = Context.GetContext();
            var names = db.agents_type.ToList();

            FilterCombo.ItemsSource = names;
            FilterCombo.SelectedValuePath = "Тип_агента";
            FilterCombo.DisplayMemberPath = "Тип_агента";

            SortCombo.ItemsSource = fields;
        }

        public void LoadData()
        {
            var db = Context.GetContext();
            allAgents = db.AgentsViews.ToList();

            foreach (var agent in allAgents)
            {
                
                if (agent.Скидка == null)
                {
                    agent.Скидка = 0;
                }
            }

            ApplyAllFiltersAndSort();
        }

        private List<AgentsView> ApplyAllFiltersAndSort()
        {
            var result = allAgents.AsEnumerable();

            if (!string.IsNullOrEmpty(currentSearchText))
            {
                result = result.Where(a => a.Наименование_организации.ToLower().Contains(currentSearchText.ToLower()));
            }

            if (!string.IsNullOrEmpty(currentFilterType))
            {
                result = result.Where(a => a.Наименование_типа_организации.Equals(currentFilterType));
            }

            if (!string.IsNullOrEmpty(currentSortField))
            {
                switch (currentSortField)
                {
                    case "Тип организации":
                        result = isAscending ?
                            result.OrderBy(p => p.Наименование_типа_организации ?? "") :
                            result.OrderByDescending(p => p.Наименование_типа_организации ?? "");
                        break;
                    case "Наименование":
                        result = isAscending ?
                            result.OrderBy(p => p.Наименование_организации ?? "") :
                            result.OrderByDescending(p => p.Наименование_организации ?? "");
                        break;
                    case "Количество продаж":
                        result = isAscending ?
                            result.OrderBy(p => p.Количество_продаж_за_год ?? int.MaxValue) :
                            result.OrderByDescending(p => p.Количество_продаж_за_год ?? int.MinValue);
                        break;
                    case "Номер телефона":
                        result = isAscending ?
                            result.OrderBy(p => p.Номер_телефона ?? "") :
                            result.OrderByDescending(p => p.Номер_телефона ?? "");
                        break;
                    case "Приоритетность":
                        result = isAscending ?
                            result.OrderBy(p => (int?)p.Приоритетность ?? int.MaxValue) :
                            result.OrderByDescending(p => (int?)p.Приоритетность ?? int.MinValue);
                        break;
                    case "Скидка":
                        result = isAscending ?
                            result.OrderBy(p => p.Скидка ?? int.MaxValue) :
                            result.OrderByDescending(p => p.Скидка ?? int.MinValue);
                        break;
                }
            }

            var filteredList = result.ToList();
            TotalPages = (int)Math.Ceiling(filteredList.Count / (double)pageSize);
            CurrentPageInfo = $"Страница {currentPage} из {TotalPages}";

            GoToPage(filteredList, 1);

            return filteredList;
        }

        private void GoToPage(List<AgentsView> agentsList, int page)
        {
            if (page < 1 || page > TotalPages) return;

            currentPage = page;
            CurrentPageInfo = $"Страница {currentPage} из {TotalPages}";
            displayedAgents.Clear();

            var skip = (page - 1) * pageSize;
            var pageItems = agentsList.Skip(skip).Take(pageSize);

            foreach (var item in pageItems)
            {
                var viewModel = new AgentViewModel(item);

                if (item.Скидка == null)
                {
                    var tempAgent = new AgentsView
                    {
                        АйдиАгента = item.АйдиАгента,
                        Наименование_типа_организации = item.Наименование_типа_организации,
                        Наименование_организации = item.Наименование_организации,
                        Количество_продаж_за_год = item.Количество_продаж_за_год,
                        Номер_телефона = item.Номер_телефона,
                        Приоритетность = item.Приоритетность,
                        Ссылка_на_логотип = item.Ссылка_на_логотип,
                        Скидка = item.Скидка ?? 0
                    };
                    viewModel = new AgentViewModel(tempAgent);
                }

                displayedAgents.Add(viewModel);
            }

            curPageTV.Text = CurrentPageInfo;

            BtnPrev.IsEnabled = currentPage > 1;
            BtnNext.IsEnabled = currentPage < TotalPages;
        }

        private void GoToPage(int page)
        {
            var filteredList = ApplyAllFiltersAndSort();
            GoToPage(filteredList, page);
        }

        private void BtnPrev_Click(object sender, RoutedEventArgs e)
        {
            GoToPage(currentPage - 1);
        }

        private void BtnNext_Click(object sender, RoutedEventArgs e)
        {
            GoToPage(currentPage + 1);
        }

        private void findBtn_Click(object sender, RoutedEventArgs e)
        {
            currentSearchText = Finder.Text;
            GoToPage(1);
        }

        private void upBtn_Click(object sender, RoutedEventArgs e)
        {
            if (SortCombo.SelectedValue != null)
            {
                currentSortField = SortCombo.SelectedValue.ToString();
                isAscending = true;
                GoToPage(1);
            }
        }

        private void dowBtn_Click(object sender, RoutedEventArgs e)
        {
            if (SortCombo.SelectedValue != null)
            {
                currentSortField = SortCombo.SelectedValue.ToString();
                isAscending = false;
                GoToPage(1);
            }
        }

        private void clearFilterBtn_Click(object sender, RoutedEventArgs e)
        {
            currentFilterType = null;
            SortCombo.SelectedItem = null;
            FilterCombo.SelectedItem = null;
            Finder.Clear();
            GoToPage(1);
        }

        private void filterBtn_Click(object sender, RoutedEventArgs e)
        {
            if (FilterCombo.SelectedValue != null)
            {
                currentFilterType = FilterCombo.SelectedValue.ToString();
                GoToPage(1);
            }
        }

        private void delBtn_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as Button;
            var agentVM = button?.DataContext as AgentViewModel;

            if (agentVM != null)
            {
                var check = Context.GetContext().productsales
                    .FirstOrDefault(z => z.АйдиАгента == agentVM.АйдиАгента);

                if (check == null)
                {
                    Context.GetContext().Database.ExecuteSqlCommand(
                        "EXEC dbo.DeleteAgent @p0", agentVM.АйдиАгента);

                    MessageBox.Show("Агент удален");
                    LoadData();
                }
                else
                {
                    MessageBox.Show("Есть связанные записи закупок");
                }
            }
        }

        private void editBtn_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as Button;
            var agentVM = button?.DataContext as AgentViewModel;

            if (agentVM != null)
            {
                main.mainFrame.Navigate(new AgentsAddPage(main, agentVM.АйдиАгента));
            }
        }

        private void addAgents_Click(object sender, RoutedEventArgs e)
        {
            main.mainFrame.Navigate(new AgentsAddPage(main));
        }
    }
}