﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PP02._02
{
    /// <summary>
    /// Логика взаимодействия для AgentsAddPage.xaml
    /// </summary>
    public partial class AgentsAddPage : Page
    {
        agent curAgent = new agent();
        MainWindow main;
        private bool isEdit = false;
        int uID;

        public AgentsAddPage(MainWindow main, int ID)
        {
            InitializeComponent();
            comboLoad();
            Load(ID);
            isEdit = true;
            this.main = main;
            uID = ID;
        }

        public AgentsAddPage(MainWindow main)
        {
            InitializeComponent();
            DataContext = curAgent;
            this.main = main;
            comboLoad();
        }

        private void comboLoad()
        {
            OrgTypeCombo.ItemsSource = Context.GetContext().agents_type.OrderBy(c => c.Тип_агента).ToList();
            OrgTypeCombo.DisplayMemberPath = "Тип_агента";
            OrgTypeCombo.SelectedValuePath = "АйдиТипа";
        }

        private void Load(int ID)
        {
            try
            {
                curAgent = Context.GetContext().agents
                    .FirstOrDefault(z => z.АйдиАгента == ID);

                if (curAgent != null)
                {
                    DataContext = curAgent;
                    OrgTypeCombo.SelectedValue = curAgent.ТипАгента;
                }
                else
                {
                    MessageBox.Show("Агент не найден");
                    main.mainFrame.Navigate(new AgentsPage(main));
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки: {ex.Message}");
            }
        }



        private void cancelBtn_Click(object sender, RoutedEventArgs e)
        {
            main.mainFrame.Navigate(new AgentsPage(main));
        }

        private void saveBtn_Click(object sender, RoutedEventArgs e)
        {
            
                if (OrgTypeCombo.SelectedValue == null)
                {
                    MessageBox.Show("Выберите тип");
                    return;
                }
                if (OrgName.Text == String.Empty || OrgPhone.Text == String.Empty || OrgAddres.Text == String.Empty
                    || OrgMail.Text == String.Empty || OrgKPP.Text == String.Empty || OrgINN.Text == String.Empty
                    || OrgDirectorFIO.Text == String.Empty)
                {
                    MessageBox.Show("Не все поля заполнены");
                    return;
                }

                curAgent.Наименование_агента = OrgName.Text;
                curAgent.Электронная_почта_агента = OrgMail.Text;
                curAgent.ТипАгента = (int)OrgTypeCombo.SelectedValue;
                curAgent.Телефон_агента = OrgPhone.Text;
                curAgent.Юридический_адрес = OrgAddres.Text;
                int priority = Context.GetContext().Database.SqlQuery<int>("SELECT MAX(Приоритет) FROM agents").First() + 1;
                curAgent.Приоритет = priority;
                curAgent.Директор = OrgDirectorFIO.Text;
                curAgent.ИНН = OrgINN.Text;
                curAgent.КПП = OrgKPP.Text;

                if (!isEdit)
                {
                    Context.GetContext().Database.ExecuteSqlCommand(
                    "EXEC dbo.InsertAgent @p0, @p1, @p2, @p3, @p4, @p5, @p6, @p7, @p8, @p9",
                    curAgent.ТипАгента,
                    curAgent.Наименование_агента,
                    curAgent.Электронная_почта_агента,
                    curAgent.Телефон_агента,
                    curAgent.Логотип_агента ?? (object)DBNull.Value,
                    curAgent.Юридический_адрес,
                    curAgent.Директор,
                    curAgent.ИНН,
                    curAgent.КПП,
                    curAgent.Скидка ?? (object)DBNull.Value
                    );
                }
            else
            {
                Context.GetContext().Database.ExecuteSqlCommand(
                "EXEC dbo.UpdateAgent @p0, @p1, @p2, @p3, @p4, @p5, @p6, @p7, @p8, @p9, @p10, @p11",
                curAgent.АйдиАгента,
                curAgent.ТипАгента,
                curAgent.Наименование_агента,
                curAgent.Электронная_почта_агента,
                curAgent.Телефон_агента,
                (object)curAgent.Логотип_агента ?? DBNull.Value,
                curAgent.Юридический_адрес,
                curAgent.Приоритет,
                curAgent.Директор,
                curAgent.ИНН,
                curAgent.КПП,
                (object)curAgent.Скидка ?? DBNull.Value);
            }

                MessageBox.Show(isEdit ? "Агент обновлен" : "Агент добавлен");

                main.mainFrame.Navigate(new AgentsPage(main));
            
            
        }
    }
}
