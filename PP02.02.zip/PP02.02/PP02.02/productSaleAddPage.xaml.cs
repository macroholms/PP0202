﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PP02._02
{
    /// <summary>
    /// Логика взаимодействия для productSaleAddPage.xaml
    /// </summary>
    public partial class productSaleAddPage : Page
    {
        productsale curProd = new productsale();
        MainWindow main;
        private bool isEdit = false;
        int ID;

        public productSaleAddPage(MainWindow main, int ID)
        {
            InitializeComponent();
            comboLoad();
            Load(ID);
            isEdit = true;
            this.ID = ID;
            this.main = main;
        }

        public productSaleAddPage(MainWindow main)
        {
            InitializeComponent();
            DataContext = curProd;
            datePicker.SelectedDate = DateTime.Now;
            this.main = main;
            comboLoad();
        }

        private void comboLoad()
        {
            OrgCombo.ItemsSource = Context.GetContext().agents.OrderBy(c => c.Наименование_агента).ToList();
            OrgCombo.DisplayMemberPath = "Наименование_агента";
            OrgCombo.SelectedValuePath = "АйдиАгента";

            ProdCombo.ItemsSource = Context.GetContext().products.OrderBy(c => c.Наименование_продукции).ToList();
            ProdCombo.DisplayMemberPath = "Наименование_продукции";
            ProdCombo.SelectedValuePath = "АйдиПродукта";
        }

        private void Load(int ID)
        {
            try
            {
                curProd = Context.GetContext().productsales
                    .FirstOrDefault(z => z.АйдиПродажи == ID);

                if (curProd != null)
                {
                    DataContext = curProd;
                    OrgCombo.SelectedValue = curProd.АйдиАгента;
                    ProdCombo.SelectedValue = curProd.АйдиПродукта;
                }
                else
                {
                    MessageBox.Show("Платеж не найден");
                    main.mainFrame.Navigate(new productSalePage(main));
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки: {ex.Message}");
            }
        }


        private void saveBtn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (OrgCombo.SelectedValue == null)
                {
                    MessageBox.Show("Выберите агента");
                    return;
                }
                if (ProdCombo.SelectedValue == null)
                {
                    MessageBox.Show("Выберите продукт");
                    return;
                }
                if (datePicker.SelectedDate == null)
                {
                    MessageBox.Show("Не выбрана дата");
                    return;
                }
                if (Count.Text == String.Empty)
                {
                    MessageBox.Show("Введите количество");
                    return;
                }

                curProd.Дата_реализации = datePicker.SelectedDate ?? DateTime.Now;
                curProd.АйдиАгента = (int)OrgCombo.SelectedValue;
                curProd.АйдиПродукта = (int)ProdCombo.SelectedValue;
                curProd.Количество_продукции = Convert.ToInt32(Count.Text);

                if (!isEdit)
                {
                    curProd.АйдиПродажи = ID;
                    Context.GetContext().productsales.Add(curProd);
                }

                Context.GetContext().SaveChanges();
                Context.GetContext().Entry(curProd).Reload();

                MessageBox.Show(isEdit ? "Закупка обновлена" : "Закупка добавлена");

                main.mainFrame.Navigate(new productSalePage(main));
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка сохранения: {ex.Message}");
            }
        }

        private void cancelBtn_Click(object sender, RoutedEventArgs e)
        {
            main.mainFrame.Navigate(new productSalePage(main));
        }
    }
}
