﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Data.Entity;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PP02._02
{
    /// <summary>
    /// Логика взаимодействия для productSalePage.xaml
    /// </summary>
    public partial class productSalePage : Page
    {
        MainWindow main;
        List<productsaleView> sales;
        public productSalePage(MainWindow main)
        {
            InitializeComponent();
            LoadData();
            this.main = main;
        }

        public void LoadData()
        {
            var db = Context.GetContext();
            sales = db.productsales
                .Include(a => a.agent)
                .Include(p => p.product)
                .ToList()
                .Select(z => new productsaleView
                {
                    АйдиПродажи = z.АйдиПродажи,
                    АйдиПродукта = z.product.Наименование_продукции,
                    АйдиАгента = z.agent.Наименование_агента,
                    Дата_реализации = z.Дата_реализации,
                    Количество_продукции = z.Количество_продукции
                })
                .ToList();

            DataG.ItemsSource = sales;
        }

        private void plusBtn_Click(object sender, RoutedEventArgs e)
        {
            main.mainFrame.Navigate(new productSaleAddPage(main));
        }

        private void minusBtn_Click(object sender, RoutedEventArgs e)
        {
            if (DataG.SelectedItem == null)
            {
                MessageBox.Show("Выберите закупку для удаления");
                return;
            }

            var itemType = DataG.SelectedItem.GetType();
            if (itemType.FullName.Contains("MS.Internal") || itemType.FullName.Contains("NamedObject"))
            {
                MessageBox.Show("Выберите действительную закупку для удаления");
                return;
            }

            var selected = DataG.SelectedItem as productsaleView;
            if (selected == null)
            {
                MessageBox.Show("Выберите закупку для удаления");
                return;
            }

            var result = MessageBox.Show($"Удалить закупку №{selected.АйдиПродажи}?", "Подтверждение", MessageBoxButton.YesNo);

            if (result == MessageBoxResult.Yes)
            {
                var orderToDelete = Context.GetContext().productsales
                    .FirstOrDefault(z => z.АйдиПродажи == selected.АйдиПродажи);

                if (orderToDelete != null)
                {
                    Context.GetContext().productsales.Remove(orderToDelete);
                    Context.GetContext().SaveChanges();

                    MessageBox.Show("Закупка удалена");
                }
            }
        }

        private void DataG_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            var itemType = DataG.SelectedItem.GetType();

            if (itemType.FullName.Contains("MS.Internal") || itemType.FullName.Contains("NamedObject"))
            {
                MessageBox.Show("Это системный объект, нельзя преобразовать в productsaleView");
                return;
            }

            var selected = DataG.SelectedItem as productsaleView;
            if (selected != null && selected.АйдиПродажи > 0)
            {
                main.mainFrame.Navigate(new productSaleAddPage(main, selected.АйдиПродажи));
            }
            else
            {
                MessageBox.Show("Не удалось преобразовать выбранный элемент в productsaleView");
            }
        }
    }

    public partial class productsaleView
    {
        public int АйдиПродажи { get; set; }
        public string АйдиПродукта { get; set; }
        public string АйдиАгента { get; set; }
        public System.DateTime Дата_реализации { get; set; }
        public int Количество_продукции { get; set; }
    }
}
