﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PP02._02
{
    /// <summary>
    /// Логика взаимодействия для AgentsPage.xaml
    /// </summary>
    public partial class AgentsPage : Page
    {
        private MainWindow main;
        private List<AgentsView> allAgents;
        private List<AgentsView> filteredAgents;
        private ObservableCollection<AgentsView> displayedAgents;
        private int currentPage = 1;
        private const int pageSize = 10;
        private string[] fields = { "Тип организации", "Наименование", "Количество продаж", "Номер телефона", "Приоритетность", "Скидка"};
        
        public string CurrentPageInfo;

        public int TotalPages;

        public AgentsPage(MainWindow main)
        {
            InitializeComponent();
            this.main = main;
            displayedAgents = new ObservableCollection<AgentsView>();
            LoadData();
            ComboLoad();
            MainListView.ItemsSource = displayedAgents;
            DataContext = this;
        }

        private void ComboLoad()
        {
            var db = Context.GetContext();
            var names = db.agents_type.ToList();

            FilterCombo.ItemsSource = names;
            FilterCombo.SelectedValuePath = "Тип_агента";
            FilterCombo.DisplayMemberPath = "Тип_агента";

            SortCombo.ItemsSource = fields;
        }

        public void LoadData()
        {
            var db = Context.GetContext();
            allAgents = db.AgentsViews.ToList();

            foreach (var agent in allAgents)
            {
                if (string.IsNullOrEmpty(agent.Ссылка_на_логотип))
                {
                    agent.Ссылка_на_логотип = "/agents/picture.png";
                }
                if (agent.Скидка == null)
                {
                    agent.Скидка = 0;
                }
            }

            filteredAgents = new List<AgentsView>(allAgents);

            TotalPages = (int)Math.Ceiling(filteredAgents.Count / (double)pageSize);
            CurrentPageInfo = $"Страница {currentPage} из {TotalPages}";

            GoToPage(1);
        }

        private void GoToPage(int page)
        {
            if (page < 1 || page > TotalPages) return;

            currentPage = page;
            CurrentPageInfo = $"Страница {currentPage} из {TotalPages}";
            displayedAgents.Clear();

            var skip = (page - 1) * pageSize;
            var pageItems = filteredAgents.Skip(skip).Take(pageSize);

            foreach (var item in pageItems)
            {
                displayedAgents.Add(item);
            }

            curPageTV.Text = CurrentPageInfo;

            BtnPrev.IsEnabled = currentPage > 1;
            BtnNext.IsEnabled = currentPage < TotalPages;
        }

        private void BtnPrev_Click(object sender, RoutedEventArgs e)
        {
            GoToPage(currentPage - 1);
        }

        private void BtnNext_Click(object sender, RoutedEventArgs e)
        {
            GoToPage(currentPage + 1);
        }

        private void findBtn_Click(object sender, RoutedEventArgs e)
        {
            filteredAgents.Clear();
            for (int i = 0; i < allAgents.Count; i++)
            {
                if (allAgents[i].Наименование_организации.ToLower().Contains(Finder.Text.ToLower()))
                {
                    filteredAgents.Add(allAgents[i]);
                }
            }
            TotalPages = (int)Math.Ceiling(filteredAgents.Count / (double)pageSize);
            GoToPage(1);
        }

        private void upBtn_Click(object sender, RoutedEventArgs e)
        {
            if (SortCombo.SelectedValue != null)
            {
                switch (SortCombo.SelectedValue)
                {
                    case "Тип организации":
                        filteredAgents = filteredAgents.OrderBy(p => p.Наименование_типа_организации ?? "").ToList();
                        break;
                    case "Наименование":
                        filteredAgents = filteredAgents.OrderBy(p => p.Наименование_организации ?? "").ToList();
                        break;
                    case "Количество продаж":
                        filteredAgents = filteredAgents.OrderBy(p => p.Количество_продаж_за_год ?? int.MaxValue).ToList();
                        break;
                    case "Номер телефона":
                        filteredAgents = filteredAgents.OrderBy(p => p.Номер_телефона ?? "").ToList();
                        break;
                    case "Приоритетность":
                        filteredAgents = filteredAgents.OrderBy(p => (int?)p.Приоритетность ?? int.MaxValue).ToList();
                        break;
                    case "Скидка":
                        filteredAgents = filteredAgents.OrderBy(p => p.Скидка ?? int.MaxValue).ToList();
                        break;
                }
            }

            GoToPage(1);
        }

        private void dowBtn_Click(object sender, RoutedEventArgs e)
        {
            if (SortCombo.SelectedValue != null)
            {
                switch (SortCombo.SelectedValue)
                {
                    case "Тип организации":
                        filteredAgents = filteredAgents.OrderByDescending(p => p.Наименование_типа_организации ?? "").ToList();
                        break;
                    case "Наименование":
                        filteredAgents = filteredAgents.OrderByDescending(p => p.Наименование_организации ?? "").ToList();
                        break;
                    case "Количество продаж":
                        filteredAgents = filteredAgents.OrderByDescending(p => p.Количество_продаж_за_год ?? int.MinValue).ToList();
                        break;
                    case "Номер телефона":
                        filteredAgents = filteredAgents.OrderByDescending(p => p.Номер_телефона ?? "").ToList();
                        break;
                    case "Приоритетность":
                        filteredAgents = filteredAgents.OrderByDescending(p => (int?)p.Приоритетность ?? int.MinValue).ToList();
                        break;
                    case "Скидка":
                        filteredAgents = filteredAgents.OrderByDescending(p => p.Скидка ?? int.MinValue).ToList();
                        break;
                }
            }

            GoToPage(1);
        }

        private void clearFilterBtn_Click(object sender, RoutedEventArgs e)
        {
            filteredAgents = new List<AgentsView>(allAgents);
            TotalPages = (int)Math.Ceiling(filteredAgents.Count / (double)pageSize);
            GoToPage(1);
        }

        private void filterBtn_Click(object sender, RoutedEventArgs e)
        {
            var a = new List<AgentsView>();
            for (int i = 0; i < filteredAgents.Count; i++)
            {
                if (filteredAgents[i].Наименование_типа_организации.Equals(FilterCombo.SelectedValue))
                {
                    a.Add(filteredAgents[i]);
                }
            }
            filteredAgents = new List<AgentsView>(a);
            TotalPages = (int)Math.Ceiling(filteredAgents.Count / (double)pageSize);
            GoToPage(1);
        }

        private void delBtn_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as Button;
            var agent = button?.DataContext as AgentsView;

            if (agent != null)
            {
                var check = Context.GetContext().productsales
                    .FirstOrDefault(z => z.АйдиАгента == agent.АйдиАгента);

                if (check == null)
                {
                    Context.GetContext().Database.ExecuteSqlCommand(
                        "EXEC dbo.DeleteAgent @p0", agent.АйдиАгента);

                    MessageBox.Show("Агент удален");
                    LoadData();
                }
                else
                {
                    MessageBox.Show("Есть связанные записи закупок");
                }
            }
        }

        private void editBtn_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as Button;
            var agent = button?.DataContext as AgentsView;

            if (agent != null) {

                main.mainFrame.Navigate(new AgentsAddPage(main, agent.АйдиАгента));
                
            }
        }

        private void addAgents_Click(object sender, RoutedEventArgs e)
        {
            main.mainFrame.Navigate(new AgentsAddPage(main));
        }
    }
}

